#include <iostream>
#include <fstream>
#include <string>
#include <map>

using namespace std;

class ItemTracker {
private:
    map<string, int> itemFrequency;
    string dataFilePath;

public:
    ItemTracker() {
        dataFilePath = "frequency.dat";
    }

    void processInputFile(const string& filePath) {
        ifstream inputFile(filePath);
        string item;

        if (inputFile.is_open()) {
            while (getline(inputFile, item)) {
                itemFrequency[item]++;
            }
            inputFile.close();
        }
        else {
            cout << "Error: Unable to open file " << filePath << endl;//error clause
        }
    }

    void saveDataToFile() {
        ofstream outputFile(dataFilePath);

        if (outputFile.is_open()) {
            for (const auto& pair : itemFrequency) {
                outputFile << pair.first << " " << pair.second << endl;
            }
            outputFile.close();
            cout << "Data saved to " << dataFilePath << endl;//prints validation of data saved to frequency.dat
        }
        else {
            cout << "Error: Unable to create output file " << dataFilePath << endl;//error clause
        }
    }

    void printItemFrequency() {//printing the frequency of the items
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    void printHistogram() {//printing the histogram with *
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; i++) {
                cout << "*";
            }
            cout << endl;
        }
    }

    void run() {
        string userInput;
        int choice;

        do {
            cout << endl;
            cout << "Menu Options:" << endl;//printing the menu and its different options
            cout << "1. Look up item frequency" << endl;
            cout << "2. Print item frequency list" << endl;
            cout << "3. Print item frequency histogram" << endl;
            cout << "4. Exit" << endl;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice) {
            case 1:// option 1 of the menu
                cout << endl;
                cout << "Enter the item to look up: ";
                cin.ignore();
                getline(cin, userInput);
                cout << "Frequency of " << userInput << ": " << itemFrequency[userInput] << endl;
                break;
            case 2://option 2 of the menu
                printItemFrequency();
                break;
            case 3://option 3 of the menu
                printHistogram();
                break;
            case 4://option 4 of the menu
                saveDataToFile();
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;//input validation
                break;
            }
        } while (choice != 4);//will loop so long as input is not 4
    }
};

int main() {
    string inputFile = "CS210_Project_Three_Input_File.txt";//including the txt file
    ItemTracker tracker;
    tracker.processInputFile(inputFile);
    tracker.run();

    return 0;
}